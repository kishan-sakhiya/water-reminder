# Water-Reminder

###  Water-Reminderr, a great application that take care of your health.If you're too busy to remember having to drink enough and regularly, don't worry, there's "Water-Reminder" to help you solve that problem.Drink water reminder is an application with main function is to help us keep water tracker we need to replenish and water drinking reminder in time. Users only need to  select a gender and enter a weight number, it will help you calculate how much water should you drink per day. You can also tracker water history, reach your daily goal to open the respective achievements, 


# Tools 
- Android Studio

# Functionalities
- Easy to use, beautiful interface.
- Based on gender, weight will let you know how much water should drink a day.
- Human body graphics to drinking water tracker
- Diverse menu of nearly 20 different drinks.
- Can choose the amount of water each time.
- Smart reminder: time mode go to bed so you don't get drink water reminder.

<div>
 <img src="https://user-images.githubusercontent.com/89068106/145699681-a94d1578-6466-42ff-814b-ff0ac858b787.jpeg" width=270 height=480>

<img src="https://user-images.githubusercontent.com/89068106/145699675-34a1afe6-752a-4162-8a58-0fec03357197.jpeg" width=270 height=480>
<!--     <td><img src="https://user-images.githubusercontent.com/89068106/145699667-8edd165b-0b32-45fd-9adb-87772fab9d59.jpeg" width=270 height=480></td> -->
 <img src="https://user-images.githubusercontent.com/89068106/145699678-42073748-d8e5-4276-b184-3941e9e02317.jpeg" width=270 height=480>


</div>


 
  <div>
 <img src="https://user-images.githubusercontent.com/89068106/145699680-6302100b-4f27-4056-a94e-a95cf18e0a86.jpeg" width=270 height=480>

<!--     <img src="https://user-images.githubusercontent.com/89068106/145699670-f27ad0f9-4571-4def-b4c2-d912fe673b31.jpeg" width=270 height=480> -->

   <img src="https://user-images.githubusercontent.com/89068106/145699671-efefa231-0394-4d7b-b53a-e5e97c9f23b4.jpeg" width=270 height=480>
  

<img src="https://user-images.githubusercontent.com/89068106/145699672-4ae6b103-7ee1-4f72-917f-d076674c57a2.jpeg" width=270 height=480>

</div>

<div>
<img src="https://user-images.githubusercontent.com/89068106/145699673-f75f3d89-217f-4d0e-ad26-7ab7d10bc9f6.jpeg" width=270 height=480>

<img src="https://user-images.githubusercontent.com/89068106/145699669-395d0857-2619-419e-86d0-f1921ec86206.jpeg" width=270 height=480>
<img src="https://user-images.githubusercontent.com/89068106/145699676-d5935e33-1e5f-4868-a59e-14f343414593.jpeg" width=270 height=480>

 </div>
 
 <div>
 <img src="https://user-images.githubusercontent.com/89068106/145699677-87f409a1-a330-496a-8056-afa39ecffae9.jpeg" width=270 height=480>
  <img src="https://user-images.githubusercontent.com/89068106/145699670-f27ad0f9-4571-4def-b4c2-d912fe673b31.jpeg" width=270 height=480>

 <img src="https://user-images.githubusercontent.com/89068106/145699679-091820b1-4eda-4517-a38b-f94c14e9acfe.jpeg" width=270 height=480>
</div>



<img src="https://user-images.githubusercontent.com/89068106/145699667-8edd165b-0b32-45fd-9adb-87772fab9d59.jpeg" width=270 height=480>

<!--     <td><img src="https://user-images.githubusercontent.com/89068106/145699680-6302100b-4f27-4056-a94e-a95cf18e0a86.jpeg" width=270 height=480></td> -->

 
